package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

val Cyan = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)
val Bg = Color(0xFF020B14)
val Mono = FontFamily.Monospace

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Bg, onSurface = Color(0xFFCFF8FF), onBackground = Color(0xFFCFF8FF))) {
                val vm: JarvisVM = viewModel()
                BackHandler(enabled = vm.screen != "main") { vm.screen = "main" }
                Box(
                    Modifier.fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFF04203A), Bg, Color(0xFF01060C))))
                        .drawBehind {
                            val step = 36.dp.toPx()
                            var x = 0f
                            while (x < size.width) { drawLine(Cyan.copy(alpha = 0.05f), Offset(x, 0f), Offset(x, size.height), 1f); x += step }
                            var y = 0f
                            while (y < size.height) { drawLine(Cyan.copy(alpha = 0.05f), Offset(0f, y), Offset(size.width, y), 1f); y += step }
                        }
                        .systemBarsPadding()
                ) {
                    when (vm.screen) {
                        "settings" -> SettingsScreen(vm)
                        "memory" -> MemoryScreen(vm)
                        else -> MainScreen(vm)
                    }
                }
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0x3300E5FF), Color(0x0F2979FF))))
            .border(1.dp, Cyan.copy(alpha = 0.3f), shape)
            .drawBehind {
                val l = 14.dp.toPx(); val w = 2.5f.dp.toPx()
                drawLine(Cyan, Offset(0f, 0f), Offset(l, 0f), w); drawLine(Cyan, Offset(0f, 0f), Offset(0f, l), w)
                drawLine(Cyan, Offset(size.width, 0f), Offset(size.width - l, 0f), w); drawLine(Cyan, Offset(size.width, 0f), Offset(size.width, l), w)
                drawLine(Cyan, Offset(0f, size.height), Offset(l, size.height), w); drawLine(Cyan, Offset(0f, size.height), Offset(0f, size.height - l), w)
                drawLine(Cyan, Offset(size.width, size.height), Offset(size.width - l, size.height), w); drawLine(Cyan, Offset(size.width, size.height), Offset(size.width, size.height - l), w)
            }
            .padding(10.dp),
        content = content
    )
}

@Composable
fun Reactor(vm: JarvisVM, modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "r")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "rot")
    val ph by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(2000, easing = LinearEasing)), label = "ph")
    val lvl by animateFloatAsState(vm.level, label = "lvl")
    val base = when {
        vm.listening -> 0.15f + lvl * 0.85f
        vm.voice.speaking -> 0.6f
        vm.thinking -> 0.35f
        else -> 0.08f
    }
    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.16f + base * 0.2f), Color.Transparent), c, r), r, c)
        for (i in 0 until 60) {
            val a = i / 60f * 2f * PI.toFloat()
            val r1 = r * 0.98f
            val r2 = if (i % 5 == 0) r * 0.91f else r * 0.95f
            drawLine(Cyan.copy(alpha = 0.4f), c + Offset(cos(a) * r1, sin(a) * r1), c + Offset(cos(a) * r2, sin(a) * r2), 1.5f)
        }
        rotate(rot, c) {
            for (s in listOf(0f, 180f)) drawArc(Cyan, s, 70f, false, c - Offset(r * 0.84f, r * 0.84f), Size(r * 1.68f, r * 1.68f), style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
        }
        rotate(-rot * 1.5f, c) {
            for (s in listOf(90f, 270f)) drawArc(Blue, s, 50f, false, c - Offset(r * 0.72f, r * 0.72f), Size(r * 1.44f, r * 1.44f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
        val n = 48
        for (i in 0 until n) {
            val a = i.toFloat() / n * 2f * PI.toFloat()
            val amp = base * (0.5f + 0.5f * sin(ph * 3 + i * 0.5f))
            val r0 = r * 0.5f
            val r1 = r0 + r * 0.06f + r * 0.2f * amp
            drawLine(Cyan.copy(alpha = 0.85f), c + Offset(cos(a) * r0, sin(a) * r0), c + Offset(cos(a) * r1, sin(a) * r1), 2.dp.toPx(), StrokeCap.Round)
        }
        val rr = r * 0.34f * (1f + 0.1f * base * sin(ph * 2))
        drawCircle(Brush.radialGradient(listOf(Color.White, Cyan, Blue.copy(alpha = 0f)), center = c, radius = rr * 1.4f), rr * 1.4f, c)
    }
}

@Composable
fun Avatar(vm: JarvisVM, box: Dp, onClick: () -> Unit) {
    Box(
        Modifier.size(box).clip(CircleShape)
            .border(2.dp, Brush.sweepGradient(listOf(Cyan, Blue, Cyan)), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val img = vm.pp
        if (img != null) {
            Image(img, null, Modifier.fillMaxSize().padding(3.dp).clip(CircleShape), contentScale = ContentScale.Crop)
        } else {
            Canvas(Modifier.fillMaxSize()) {
                val c = center; val r = size.minDimension / 2
                drawCircle(Brush.radialGradient(listOf(Color(0xFF0A3555), Bg), c, r), r, c)
                drawCircle(Cyan, r * 0.62f, c, style = Stroke(2.dp.toPx()))
                drawArc(Blue, 200f, 100f, false, c - Offset(r * 0.78f, r * 0.78f), Size(r * 1.56f, r * 1.56f), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
                drawCircle(Brush.radialGradient(listOf(Color.White, Cyan, Color.Transparent), c, r * 0.4f), r * 0.4f, c)
            }
        }
    }
}

@Composable
fun IconBtn(kind: String, active: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(50.dp).clip(CircleShape)
            .background(if (active) Cyan.copy(alpha = 0.4f) else Cyan.copy(alpha = 0.12f))
            .border(1.5.dp, Cyan, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(22.dp)) {
            val w = size.width; val h = size.height
            val st = Stroke(2.dp.toPx(), cap = StrokeCap.Round)
            when (kind) {
                "mic" -> {
                    drawRoundRect(Cyan, Offset(w * 0.35f, 0f), Size(w * 0.3f, h * 0.55f), CornerRadius(w * 0.15f), style = st)
                    drawArc(Cyan, 0f, 180f, false, Offset(w * 0.2f, h * 0.2f), Size(w * 0.6f, h * 0.5f), style = st)
                    drawLine(Cyan, Offset(w / 2, h * 0.7f), Offset(w / 2, h), st.width)
                }
                "send" -> {
                    val p = Path().apply { moveTo(w * 0.1f, h * 0.1f); lineTo(w * 0.95f, h / 2); lineTo(w * 0.1f, h * 0.9f); lineTo(w * 0.3f, h / 2); close() }
                    drawPath(p, Cyan)
                }
                else -> drawRect(Cyan, Offset(w * 0.2f, h * 0.2f), Size(w * 0.6f, h * 0.6f))
            }
        }
    }
}

@Composable
fun HudButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, Cyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp)
    ) { Text(text, fontFamily = Mono, fontSize = 11.sp, color = Cyan) }
}

@Composable
fun StatusBar(vm: JarvisVM) {
    val m = vm.store.model.ifBlank { if (vm.store.provider == "gemini") "gemini-flash-lite-latest" else "gpt-4o-mini" }
    val lat = if (vm.ttfb > 0) "⏱ %.1fs".format(vm.ttfb / 1000f) else "⏱ --"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("PİL ${vm.battery}", fontFamily = Mono, fontSize = 11.sp, color = Cyan)
        Text(if (vm.online) "● ÇEVRİMİÇİ" else "○ ÇEVRİMDIŞI", fontFamily = Mono, fontSize = 11.sp, color = if (vm.online) Cyan else Color(0xFFFF5252))
        Text(lat, fontFamily = Mono, fontSize = 11.sp, color = Cyan)
        Text(m.take(14), fontFamily = Mono, fontSize = 11.sp, color = Cyan.copy(alpha = 0.7f))
    }
}

@Composable
fun Chat(vm: JarvisVM, modifier: Modifier) {
    val ls = rememberLazyListState()
    LaunchedEffect(vm.msgs.size, vm.msgs.lastOrNull()?.text?.length) {
        if (vm.msgs.isNotEmpty()) ls.scrollToItem(vm.msgs.lastIndex)
    }
    Glass(modifier) {
        if (vm.msgs.isEmpty()) Text("Sistem çevrimiçi. Komutunu bekliyorum.", fontFamily = Mono, color = Cyan.copy(alpha = 0.7f), fontSize = 13.sp)
        LazyColumn(state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.msgs.size) { i ->
                val m = vm.msgs[i]
                val user = m.role == "user"
                val col = if (user) Blue else Cyan
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (user) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(12.dp))
                            .background(col.copy(alpha = if (user) 0.25f else 0.1f))
                            .border(1.dp, col.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) { Text(m.text.ifEmpty { "…" }, fontSize = 14.sp) }
                }
            }
        }
    }
}

@Composable
fun MainScreen(vm: JarvisVM) {
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) vm.toggleMic() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) vm.setPp(uri) }
    val onMic = {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) vm.toggleMic()
        else perm.launch(Manifest.permission.RECORD_AUDIO)
    }
    var input by remember { mutableStateOf("") }
    val state = when {
        vm.listening -> "DİNLİYOR"
        vm.thinking -> "DÜŞÜNÜYOR"
        vm.voice.speaking -> "KONUŞUYOR"
        else -> "HAZIR"
    }
    BoxWithConstraints(Modifier.fillMaxSize().padding(10.dp)) {
        val wide = maxWidth > 700.dp
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Avatar(vm, 46.dp) { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                Column(Modifier.weight(1f)) {
                    Text("J.A.R.V.I.S", fontFamily = Mono, fontSize = 20.sp, color = Cyan, letterSpacing = 3.sp)
                    Text("KİŞİSEL YAPAY ZEKA ASİSTANI", fontFamily = Mono, fontSize = 9.sp, color = Cyan.copy(alpha = 0.6f))
                }
                HudButton("HAFIZA") { vm.screen = "memory" }
                HudButton("AYAR") { vm.screen = "settings" }
            }
            Glass(Modifier.fillMaxWidth()) { StatusBar(vm) }
            if (wide) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Reactor(vm, Modifier.weight(1f).aspectRatio(1f))
                        Text(state, fontFamily = Mono, color = Cyan, letterSpacing = 5.sp)
                    }
                    Chat(vm, Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                Reactor(vm, Modifier.align(Alignment.CenterHorizontally).height(210.dp).aspectRatio(1f))
                Text(state, fontFamily = Mono, color = Cyan, letterSpacing = 5.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                Chat(vm, Modifier.weight(1f).fillMaxWidth())
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Saat" to "Saat kaç ve bugün günlerden ne?", "Pil" to "Pil durumum nedir?", "Hava" to "Bugün hava nasıl?", "Haberler" to "Bugünün önemli haberleri neler?").forEach { (l, q) ->
                    HudButton(l) { vm.send(q) }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(
                    input, { input = it }, Modifier.weight(1f), placeholder = { Text("Komut yaz…") }, singleLine = true,
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Cyan.copy(alpha = 0.4f)),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { vm.send(input); input = "" })
                )
                IconBtn("mic", vm.listening) { onMic() }
                if (vm.thinking) IconBtn("stop", true) { vm.cancel() }
                else IconBtn("send", false) { vm.send(input); input = "" }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: JarvisVM) {
    val s = vm.store
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> if (uri != null) vm.setPp(uri) }
    var provider by remember { mutableStateOf(s.provider) }
    var key by remember { mutableStateOf(s.apiKey) }
    var model by remember { mutableStateOf(s.model) }
    var base by remember { mutableStateOf(s.baseUrl) }
    var ground by remember { mutableStateOf(s.grounding) }
    var speak by remember { mutableStateOf(s.speak) }
    var speed by remember { mutableFloatStateOf(s.speed) }
    Column(Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("AYARLAR", fontFamily = Mono, color = Cyan, fontSize = 18.sp, letterSpacing = 3.sp)
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Avatar(vm, 56.dp) { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                HudButton("FOTOĞRAF SEÇ") { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                if (vm.pp != null) HudButton("KALDIR") { vm.removePp() }
            }
        }
        Glass(Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(provider == "gemini", { provider = "gemini" }, { Text("Gemini") })
                FilterChip(provider == "openai", { provider = "openai" }, { Text("OpenAI uyumlu") })
            }
            OutlinedTextField(key, { key = it }, Modifier.fillMaxWidth(), label = { Text("API anahtarı (şifreli saklanır)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true)
            OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("Model (boş = en hızlı varsayılan)") }, singleLine = true)
            if (provider == "openai") OutlinedTextField(base, { base = it }, Modifier.fillMaxWidth(), label = { Text("Base URL") }, singleLine = true)
            else Row(verticalAlignment = Alignment.CenterVertically) { Switch(ground, { ground = it }); Spacer(Modifier.width(8.dp)); Text("Güncel bilgi gerekince web araması", fontSize = 13.sp) }
        }
        Glass(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) { Switch(speak, { speak = it }); Spacer(Modifier.width(8.dp)); Text("Yanıtları sesli oku") }
            Text("Konuşma hızı: %.1fx".format(speed))
            Slider(speed, { speed = it }, valueRange = 0.5f..1.8f)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({
                s.provider = provider; s.apiKey = key; s.model = model; s.baseUrl = base; s.grounding = ground; s.speak = speak; s.speed = speed
                vm.screen = "main"
            }) { Text("KAYDET") }
            OutlinedButton({ vm.screen = "main" }) { Text("GERİ") }
        }
        Text("Gemini anahtarı: aistudio.google.com. Anahtar yalnızca bu cihazda şifreli tutulur. Yavaşsa ekrandaki ⏱ süresine bak: büyükse sebep ağ veya API'dir.", fontSize = 12.sp, color = Cyan.copy(alpha = 0.6f))
    }
}

@Composable
fun MemoryScreen(vm: JarvisVM) {
    var n by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("HAFIZA", fontFamily = Mono, color = Cyan, fontSize = 18.sp, letterSpacing = 3.sp)
            HudButton("GERİ") { vm.screen = "main" }
        }
        Text("JARVIS sadece senin onayınla kaydeder. Buradan silebilirsin.", fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(n, { n = it }, Modifier.weight(1f), placeholder = { Text("Yeni bilgi ekle") }, singleLine = true)
            Button({ vm.addMemory(n); n = "" }) { Text("EKLE") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.memories.size) { i ->
                Glass(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(vm.memories[i], Modifier.weight(1f))
                        TextButton({ vm.deleteMemory(i) }) { Text("SİL") }
                    }
                }
            }
        }
        if (vm.memories.isEmpty()) Text("Henüz kayıt yok.", color = Cyan.copy(alpha = 0.6f))
    }
}

package com.jarvis.assistant

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.ConnectivityManager
import android.net.Uri
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Msg(val role: String, val text: String)

class JarvisVM(app: Application) : AndroidViewModel(app) {
    val store = Store(app)
    private val llm = Llm(store)
    private val tr = Locale.forLanguageTag("tr-TR")
    private val webRe = Regex("hava|haber|bugün|güncel|son dakika|fiyat|dolar|euro|altın|borsa|skor|maç|araştır|kim kazandı|ne oldu")
    val msgs = mutableStateListOf<Msg>()
    val memories = mutableStateListOf<String>()
    var thinking by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var level by mutableFloatStateOf(0f)
    var ttfb by mutableLongStateOf(0L)
    var battery by mutableStateOf("--")
    var online by mutableStateOf(true)
    var screen by mutableStateOf("main")
    var pp by mutableStateOf<ImageBitmap?>(null)
    val voice = Voice(app) { level = it }
    private var job: Job? = null

    init {
        memories.addAll(store.memories())
        File(app.filesDir, "pp.jpg").let { f ->
            if (f.exists()) pp = runCatching { BitmapFactory.decodeFile(f.path)?.asImageBitmap() }.getOrNull()
        }
        viewModelScope.launch {
            while (true) {
                battery = runCatching { Actions.batteryText(getApplication<Application>()).substringBefore(" (") }.getOrDefault("--")
                val cm = getApplication<Application>().getSystemService(ConnectivityManager::class.java)
                online = cm.activeNetwork != null
                delay(10000)
            }
        }
    }

    fun setPp(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val bmp: Bitmap = runCatching {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                var s = 1
                while (o.outWidth / (s * 2) >= 512 && o.outHeight / (s * 2) >= 512) s *= 2
                val o2 = BitmapFactory.Options().apply { inSampleSize = s }
                val b = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                if (b == null) null else {
                    val d = minOf(b.width, b.height)
                    Bitmap.createBitmap(b, (b.width - d) / 2, (b.height - d) / 2, d, d)
                }
            }.getOrNull() ?: return@launch
            File(ctx.filesDir, "pp.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            withContext(Dispatchers.Main) { pp = bmp.asImageBitmap() }
        }
    }

    fun removePp() { File(getApplication<Application>().filesDir, "pp.jpg").delete(); pp = null }

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("d MMMM yyyy EEEE HH:mm", tr).format(Date())
        val mem = store.memories().joinToString("\n") { "- $it" }.ifEmpty { "(boş)" }
        return """Sen JARVIS'sin: kullanıcının Android telefonundaki kişisel yapay zeka asistanısın. Varsayılan dilin Türkçe, kullanıcı İngilizce yazarsa İngilizce yanıtla. Kısa, net ve doğal konuş.
Şu an: $now
Kullanıcı hafızası:
$mem

Cihazda iş yapmak için yanıtının SONUNA şu biçimde eylem ekleyebilirsin: [[ACTION:{"type":"...", ...}]]
Eylemler: open_app(arg=uygulama adı), open_url(arg), web_search(arg), navigate(arg=yer), set_alarm(hour,minute,label), set_timer(seconds,label), battery, time, device_info, remember(arg).
Kurallar:
- Eylemi yalnızca kullanıcı istediğinde ekle. Eylemin sonucunu sen bilmezsin; uygulama doğrular ve gösterir. Asla "yaptım" diye iddia etme, "başlatıyorum" de.
- battery, time, device_info eylemlerinde sayıyı kendin söyleme, uygulama gösterecek.
- remember eylemini yalnızca kullanıcı "hatırla" derse veya sorup onay alırsan kullan. Şifre, kart no gibi hassas bilgiyi asla kaydetme.
- Güncel bilgiyi uydurma; emin değilsen bunu söyle. Doğrulanmış bilgiyi tahminden ayır."""
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || thinking) return
        voice.stopSpeaking()
        msgs.add(Msg("user", t)); msgs.add(Msg("assistant", ""))
        val idx = msgs.lastIndex
        thinking = true; ttfb = 0L
        val t0 = SystemClock.elapsedRealtime()
        val needWeb = webRe.containsMatchIn(t.lowercase(tr))
        job = viewModelScope.launch {
            val full = StringBuilder()
            var err: String? = null
            var spoken = 0
            llm.chat(msgs.take(idx).takeLast(12).map { it.role to it.text }, systemPrompt(), needWeb)
                .catch { err = it.message ?: "Bilinmeyen hata" }
                .collect { d ->
                    if (ttfb == 0L) ttfb = SystemClock.elapsedRealtime() - t0
                    full.append(d)
                    val now = Actions.strip(full.toString())
                    msgs[idx] = Msg("assistant", now)
                    if (store.speak) {
                        val end = now.indexOfLast { it == '.' || it == '!' || it == '?' || it == '\n' }
                        if (end + 1 > spoken) { voice.enqueue(now.substring(spoken, end + 1), store.speed); spoken = end + 1 }
                    }
                }
            val raw = full.toString()
            val clean = Actions.strip(raw)
            val results = Actions.parse(raw).map { Actions.run(getApplication<Application>(), store, it) }
            memories.clear(); memories.addAll(store.memories())
            val extra = results.joinToString("\n") { "▸ ${it.status.uppercase()}: ${it.msg}" }
            val errText = err?.let { "⚠ Hata: $it" } ?: ""
            msgs[idx] = Msg("assistant", listOf(clean, extra, errText).filter { it.isNotEmpty() }.joinToString("\n\n").ifEmpty { "…" })
            thinking = false
            if (store.speak) {
                val rest = clean.substring(spoken.coerceAtMost(clean.length))
                voice.enqueue((listOf(rest) + results.filter { it.status == "done" }.map { it.msg }).filter { it.isNotBlank() }.joinToString(". "), store.speed)
            }
        }
    }

    fun cancel() { job?.cancel(); thinking = false; voice.stopSpeaking() }

    fun toggleMic() {
        if (listening) { voice.stopListening(); listening = false; level = 0f; return }
        voice.stopSpeaking()
        listening = true
        voice.listen(
            onFinal = { t -> listening = false; level = 0f; if (t.isNotBlank()) send(t) },
            onEnd = { listening = false; level = 0f }
        )
    }

    fun deleteMemory(i: Int) { store.deleteMemory(i); memories.clear(); memories.addAll(store.memories()) }
    fun addMemory(s: String) { store.addMemory(s); memories.clear(); memories.addAll(store.memories()) }
    override fun onCleared() { voice.release() }
}

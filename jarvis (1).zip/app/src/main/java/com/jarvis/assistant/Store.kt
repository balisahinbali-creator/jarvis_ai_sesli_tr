package com.jarvis.assistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray

class Store(ctx: Context) {
    private val sec = EncryptedSharedPreferences.create(
        ctx, "secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    private val p = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    var apiKey: String
        get() = sec.getString("key", "") ?: ""
        set(v) { sec.edit().putString("key", v.trim()).apply() }
    var provider: String
        get() = p.getString("provider", "gemini") ?: "gemini"
        set(v) { p.edit().putString("provider", v).apply() }
    var model: String
        get() = p.getString("model", "") ?: ""
        set(v) { p.edit().putString("model", v.trim()).apply() }
    var baseUrl: String
        get() = p.getString("base", "https://api.openai.com/v1") ?: ""
        set(v) { p.edit().putString("base", v.trim()).apply() }
    var grounding: Boolean
        get() = p.getBoolean("grounding", true)
        set(v) { p.edit().putBoolean("grounding", v).apply() }
    var speak: Boolean
        get() = p.getBoolean("speak", true)
        set(v) { p.edit().putBoolean("speak", v).apply() }
    var speed: Float
        get() = p.getFloat("speed", 1.0f)
        set(v) { p.edit().putFloat("speed", v).apply() }

    fun memories(): List<String> {
        val a = JSONArray(p.getString("mem", "[]"))
        return List(a.length()) { a.getString(it) }
    }
    private fun saveMem(l: List<String>) { p.edit().putString("mem", JSONArray(l).toString()).apply() }
    fun addMemory(s: String) { val l = memories(); val t = s.trim(); if (t.isNotEmpty() && t !in l) saveMem(l + t) }
    fun deleteMemory(i: Int) { val l = memories().toMutableList(); if (i in l.indices) { l.removeAt(i); saveMem(l) } }
}

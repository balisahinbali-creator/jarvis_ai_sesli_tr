package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

class Voice(private val ctx: Context, private val onLevel: (Float) -> Unit) {
    var speaking by mutableStateOf(false)
    private var sr: SpeechRecognizer? = null
    private var ready = false
    private val pending = AtomicInteger(0)
    private val counter = AtomicInteger(0)
    private val tr = Locale.forLanguageTag("tr-TR")
    private val tts: TextToSpeech = TextToSpeech(ctx) { st ->
        if (st == TextToSpeech.SUCCESS) { ready = true; init2() }
    }

    private fun init2() {
        tts.language = tr
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { speaking = true }
            override fun onDone(id: String?) { speaking = pending.decrementAndGet() > 0 }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { speaking = pending.decrementAndGet() > 0 }
        })
    }

    fun enqueue(text: String, rate: Float) {
        if (!ready || text.isBlank()) return
        tts.setSpeechRate(rate)
        pending.incrementAndGet()
        tts.speak(text, TextToSpeech.QUEUE_ADD, null, "j" + counter.incrementAndGet())
    }

    fun stopSpeaking() { if (ready) tts.stop(); pending.set(0); speaking = false }

    fun listen(onFinal: (String) -> Unit, onEnd: () -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            Toast.makeText(ctx, "Bu cihazda konuşma tanıma servisi yok", Toast.LENGTH_LONG).show()
            onEnd(); return
        }
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) { onLevel(((v + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) { onEnd() }
            override fun onResults(b: Bundle?) {
                onFinal(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "")
            }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR"))
    }

    fun stopListening() { sr?.stopListening() }
    fun release() { sr?.destroy(); tts.shutdown() }
}

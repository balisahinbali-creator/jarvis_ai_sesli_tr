package com.jarvis.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Result(val status: String, val msg: String)

object Actions {
    private val re = Regex("""\[\[ACTION:(.*?)\]\]""", RegexOption.DOT_MATCHES_ALL)
    private val tr = Locale.forLanguageTag("tr-TR")

    fun strip(s: String): String = s.replace(re, "").substringBefore("[[ACTION").trim()

    fun parse(s: String): List<JSONObject> =
        re.findAll(s).mapNotNull { runCatching { JSONObject(it.groupValues[1]) }.getOrNull() }.toList()

    private fun launch(ctx: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true
    } catch (e: ActivityNotFoundException) { false } catch (e: SecurityException) { false }

    fun run(ctx: Context, store: Store, a: JSONObject): Result {
        val arg = a.optString("arg")
        return when (a.optString("type")) {
            "open_app" -> {
                val pm = ctx.packageManager
                val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                val w = arg.lowercase(tr)
                val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase(tr) == w }
                    ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase(tr).contains(w) }
                val li = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
                when {
                    hit == null || li == null -> Result("failed", "Yüklü uygulamalarda bulunamadı: $arg")
                    launch(ctx, li) -> Result("started", "${hit.loadLabel(pm)} açma isteği gönderildi")
                    else -> Result("failed", "Uygulama açılamadı: $arg")
                }
            }
            "open_url" -> {
                val u = if (arg.startsWith("http")) arg else "https://$arg"
                if (launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) Result("started", "Açılıyor: $u") else Result("failed", "Tarayıcı bulunamadı")
            }
            "web_search" -> {
                val u = "https://www.google.com/search?q=" + URLEncoder.encode(arg, "UTF-8")
                if (launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) Result("started", "Aranıyor: $arg") else Result("failed", "Tarayıcı bulunamadı")
            }
            "navigate" -> {
                val u = "geo:0,0?q=" + URLEncoder.encode(arg, "UTF-8")
                if (launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u)))) Result("started", "Harita açılıyor: $arg") else Result("failed", "Harita uygulaması yok")
            }
            "set_alarm" -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "JARVIS"))
                if (launch(ctx, i)) Result("started", "Alarm ekranı açıldı, onaylaman gerekiyor (%02d:%02d)".format(a.optInt("hour"), a.optInt("minute")))
                else Result("failed", "Saat uygulaması bulunamadı")
            }
            "set_timer" -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "JARVIS"))
                if (launch(ctx, i)) Result("started", "Zamanlayıcı isteği gönderildi") else Result("failed", "Saat uygulaması bulunamadı")
            }
            "battery" -> Result("done", batteryText(ctx))
            "time" -> Result("done", SimpleDateFormat("d MMMM yyyy EEEE, HH:mm", tr).format(Date()))
            "device_info" -> Result("done", "${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}")
            "remember" -> { store.addMemory(arg); Result("done", "Hafızaya kaydedildi: $arg") }
            else -> Result("failed", "Bilinmeyen eylem: ${a.optString("type")}")
        }
    }

    fun batteryText(ctx: Context): String {
        val bm = ctx.getSystemService(BatteryManager::class.java)
        val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return if (bm.isCharging) "Pil %$lvl (şarj oluyor)" else "Pil %$lvl"
    }
}
